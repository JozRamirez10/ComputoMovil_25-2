//
//  CompuMoviliOS_DemoApp.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

@main
struct CompuMoviliOS_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            StartScreen_View()
        }
    }
}


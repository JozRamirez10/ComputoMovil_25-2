//
//  Workout_View.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

struct Workout_View: View {
    var body: some View {
        VStack(spacing: 24) {
            
            // Encabezado
            HStack {
                Image(systemName: "waveform.path.ecg")
                    .foregroundColor(.white)
                Text("Workout")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Spacer()
                Image(systemName: "line.3.horizontal")
                    .foregroundColor(.white)
            }
            .padding()
            .background(Color.blue.opacity(0.3))

            Text("Types of exercise")
                .fontWeight(.bold)
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 10) // Usando RoundedRectangle para el fondo
                                .fill(Color.blue.opacity(0.9)))
                .foregroundColor(.white)
                .padding(.horizontal)

            // Botones con enlaces a YouTube
            VStack(spacing: 20) {
                ExerciseCategoryButton(
                    title: "Running",
                    color: .red,
                    youtubeURL: URL(string: "https://www.youtube.com/watch?v=GcZJhNi2yOM&t=13s")!
                )
                ExerciseCategoryButton(
                    title: "Stretching",
                    color: .purple,
                    youtubeURL: URL(string: "https://www.youtube.com/watch?v=y87vSUoIMGU")!
                )
                ExerciseCategoryButton(
                    title: "Strength",
                    color: .orange,
                    youtubeURL: URL(string: "https://www.youtube.com/watch?v=BwaoD94HVq0")!
                )
            }
            .padding(.horizontal)

            Spacer()
        }
    }
}

// Botón reutilizable
struct ExerciseCategoryButton: View {
    let title: String
    let color: Color
    let youtubeURL: URL

    var body: some View {
        Button(action: {
            UIApplication.shared.open(youtubeURL)
        }) {
            HStack {
                Spacer()
                Text(title)
                    .font(.title)
                    .foregroundColor(.white)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.white)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .frame(height: 150)
            .background(color)
            .cornerRadius(12)
        }
    }
}

#Preview {
    Workout_View()
}

//
//  Meditation_View.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

struct Meditation_View: View {
    var body: some View {
        VStack(spacing: 20) {

            // Encabezado
            HStack {
                Image(systemName: "gift.fill")
                    .foregroundColor(.white)
                Text("Surprise meditation")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Spacer()
                Image(systemName: "line.3.horizontal")
                    .foregroundColor(.white)
            }
            .padding()
            .background(Color.orange)

            // Sección principal
            ScrollView {
                VStack(spacing: 24) {

                    // Título sección
                    Text("Meditation")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10) // Usando RoundedRectangle para el fondo
                                        .fill(Color.orange.opacity(0.9)))
                        .foregroundColor(.white)
                        .padding(.horizontal)

                    // Imagen de meditación
                    Rectangle()
                        .fill(Color.gray.opacity(0.3))
                        .frame(height: 180)
                        .cornerRadius(12)
                        .padding(.horizontal)

                    // Descripción
                    VStack {
                        VStack(alignment: .leading, spacing: 8) {
                            Rectangle()
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 16)
                                .cornerRadius(4)

                            Rectangle()
                                .fill(Color.gray.opacity(0.15))
                                .frame(height: 40)
                                .cornerRadius(4)
                        }
                        .padding()  // Padding interno del contenedor
                        .background(Color.white)  // Fondo blanco para el área de contenido
                        .cornerRadius(12)  // Bordes redondeados del contenedor
                        .shadow(radius: 5)  // Sombra opcional para mejorar el contraste
                    }
                    .padding(.horizontal)  // Margen horizontal para que no se pegue a los lados de la pantalla
                    


                    // Temporizador y botón de reproducción
                        
                    VStack(spacing: 35) {
                        HStack(spacing: 8){
                            Image(systemName: "hourglass")
                            Text("10:00")
                                .font(.title)
                        }
                        Button(action: {
                            // Acción futura para iniciar meditación
                        }) {
                            Image(systemName: "play.circle.fill")
                                .resizable()
                                .foregroundColor(.orange)
                                .frame(width: 100, height: 100)
                        }
                    }
                    .padding(.top)
                        
                }
                .padding(.top, 20)
            }
        }
    }
}

#Preview {
    Meditation_View()
}

//
//  Forums_View.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

struct Forums_View: View {
    var body: some View {
        VStack(spacing: 16) {

            // Encabezado
            HStack {
                Image(systemName: "paperplane.fill") // Ícono para el foro
                    .foregroundColor(.white)
                Text("Forums")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Spacer()
                Image(systemName: "line.3.horizontal") // Menú hamburguesa
                    .foregroundColor(.white)
            }
            .padding()
            .background(Color.yellow)

            // Lista de publicaciones
            ScrollView {
                VStack(spacing: 16) {
                    ForEach(0..<5) { index in
                        ForumPostCard()
                    }
                }
                .padding()
            }

            // Navegación de página
            HStack(spacing: 20) {
                Button(action: {}) {
                    Image(systemName: "chevron.backward.2")
                }
                Button(action: {}) {
                    Image(systemName: "chevron.backward")
                }

                Text("1")
                    .font(.headline)

                Button(action: {}) {
                    Image(systemName: "chevron.forward")
                }
                Button(action: {}) {
                    Image(systemName: "chevron.forward.2")
                }
            }
            .padding(.bottom)
            .foregroundColor(.gray)
        }
    }
}

// Tarjeta de publicación del foro (placeholder visual)
struct ForumPostCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Rectangle()
                .fill(Color.gray.opacity(0.2))
                .frame(height: 16)
                .cornerRadius(4)

            Rectangle()
                .fill(Color.gray.opacity(0.15))
                .frame(height: 40)
                .cornerRadius(4)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

#Preview {
    Forums_View()
}

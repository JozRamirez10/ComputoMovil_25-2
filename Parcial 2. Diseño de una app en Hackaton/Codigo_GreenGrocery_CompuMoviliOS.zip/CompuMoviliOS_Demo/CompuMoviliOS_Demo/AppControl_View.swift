//
//  AppControl_View.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

struct AppControl_View: View {
    var body: some View {
        VStack(spacing: 20) {
            
            // Encabezado
            HStack {
                Image(systemName: "face.smiling.fill") // Ícono decorativo
                    .foregroundColor(.white)
                Text("App control")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Spacer()
                Image(systemName: "line.3.horizontal") // Menú
                    .foregroundColor(.white)
            }
            .padding()
            .background(Color.green)

            ScrollView {
                VStack(spacing: 24) {
                    
                    // Texto de control
                    Text("Take control of your screen time")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .cornerRadius(10)
                        .padding(.horizontal)

                    // Gráfico e info apps
                    VStack {
                        Image(systemName: "chart.pie.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                            .foregroundColor(.black)

                        Text("3h 25 min")
                            .font(.subheadline)

                        HStack(spacing: 16) {
                            Label("YouTube", systemImage: "circle.fill")
                            Label("Snapchat", systemImage: "circle.fill")
                            Label("Facebook", systemImage: "circle.fill")
                        }
                        .font(.caption)
                        .foregroundColor(.black)
                    }

                    // Título de resumen
                    Text("Today's summary")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .cornerRadius(10)
                        .padding(.horizontal)

                    // Lista de apps
                    VStack(spacing: 16) {
                        ForEach(appUsageData, id: \.self) { app in
                            AppControlRow(app: app)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
        }
    }
}

// MARK: - Modelo de App
struct AppUsage: Hashable {
    let name: String
    let time: String
    let icon: String
    let color: Color
}

let appUsageData: [AppUsage] = [
    AppUsage(name: "YouTube", time: "3h 25 min", icon: "play.rectangle.fill", color: .red),
    AppUsage(name: "Snapchat", time: "2h 56 min", icon: "bolt.fill", color: .yellow),
    AppUsage(name: "Facebook", time: "1h 41 min", icon: "f.square.fill", color: .blue),
    AppUsage(name: "Messenger", time: "38 min", icon: "message.fill", color: .purple)
]

// MARK: - Vista por App
struct AppControlRow: View {
    let app: AppUsage

    var body: some View {
        HStack {
            // Ícono y nombre
            Label {
                VStack(alignment: .leading) {
                    Text(app.name)
                        .font(.headline)
                    Text(app.time)
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            } icon: {
                Circle()
                    .fill(app.color)
                    .frame(width: 30, height: 30)
                    .overlay(Image(systemName: app.icon)
                        .foregroundColor(.white)
                        .font(.system(size: 16)))
            }

            Spacer()

            // Botón y menú de bloqueo
            Menu {
                Button("For 1 hour", action: {})
                Button("For 3 hours", action: {})
                Button("For rest of day", action: {})
            } label: {
                HStack {
                    Image(systemName: "chevron.down")
                    Text("Block app")
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(8)
                .font(.subheadline)
            }
        }
        .padding()
        .background(Color(UIColor.systemGray6))
        .cornerRadius(12)
    }
}

#Preview {
    AppControl_View()
}

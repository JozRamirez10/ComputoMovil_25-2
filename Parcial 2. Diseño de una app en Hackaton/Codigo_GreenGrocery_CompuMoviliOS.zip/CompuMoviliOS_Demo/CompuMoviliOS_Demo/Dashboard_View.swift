//
//  Dashboard_View.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

struct Dashboard_View: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {

                // Bienvenida
                HStack {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .foregroundColor(.green)

                    Text("Hi! Name, welcome back!")
                        .font(.headline)
                        .foregroundColor(.black)
                }
                .padding(.horizontal)

                // App Usage Summary
                GroupBox(label: NavigationLink(destination: AppControl_View()) {
                    Text("Today's app summary")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }) {
                    HStack(spacing: 12) {
                        VStack {
                            Text("45%")
                            Text("Active")
                                .font(.caption)
                                .fontWeight(.bold)
                        }
                        VStack {
                            Text("2h")
                            Text("Screen")
                                .font(.caption)
                                .fontWeight(.bold)
                        }
                        VStack {
                            Text("1/1")
                            Text("Meditation")
                                .font(.caption)
                                .fontWeight(.bold)
                        }
                        Image("control") // Asegúrate de tener esta imagen en tus assets
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }
                    .padding()
                }
                .padding(.horizontal)

                // Workout
                GroupBox(label: NavigationLink(destination: Workout_View()) {
                    Text("Workout")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }) {
                    HStack(spacing: 12) {
                        Image("workout") // Asegúrate de tener esta imagen en tus assets
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                        Text("Choose differents types of exercise.")
                            .font(.subheadline)
                            .fontWeight(.bold)
                            
                        
                    }
                    .padding()
                }
                .padding(.horizontal)
                

                // Surprise Meditation
                GroupBox(label: NavigationLink(destination:
                    Meditation_View()) {
                    Text("Discover your meditation")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }) {
                    HStack(spacing: 12) {
                        Text("Take a moment to relax.")
                            .font(.subheadline)
                            .fontWeight(.bold)
                        Image("meditation") // Asegúrate de tener esta imagen en tus assets
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                        
                    }
                    .padding()
                }
                .padding(.horizontal)
                
                // Forums
                GroupBox(label: NavigationLink(destination: Forums_View()) {
                    Text("Forums")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.yellow)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }) {
                    HStack(spacing: 12) {
                        Image("forums") // Asegúrate de tener esta imagen en tus assets
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                        Text("Sharing your progress.")
                            .font(.subheadline)
                            .fontWeight(.bold)
                        
                    }
                    .padding()
                }
                .padding(.horizontal)

                
                // Botón para ir a App Control
                NavigationLink(destination: LoginScreen_View()) {
                    Text("Logout")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }

                Spacer()
                
                
            }
            .padding(.vertical)
        }
        .navigationBarHidden(true)
    }
}

#Preview {
    Dashboard_View()
}

//
//  StartScreen_View.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

struct StartScreen_View: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color.green
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 40) {
                    // App Logo
                    Image("logo") // Asegúrate de tener esta imagen en tus assets
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)

                    // App Name
                    Text("GreenGrocery!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)

                    // Continue Button
                    NavigationLink(destination: LoginScreen_View()) {
                        Text("Continue")
                            .fontWeight(.semibold)
                            .padding()
                            .frame(maxWidth: 200)
                            .background(Color.white)
                            .foregroundColor(.green)
                            .cornerRadius(12)
                    }
                }
            }
        }
    }
}

#Preview {
    StartScreen_View()
}



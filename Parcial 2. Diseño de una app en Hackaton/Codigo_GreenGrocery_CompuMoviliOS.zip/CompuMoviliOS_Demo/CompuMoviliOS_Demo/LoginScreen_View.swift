//
//  LoginScreen_View.swift
//  CompuMoviliOS_Demo
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

struct LoginScreen_View: View {
    @State private var username: String = ""
    @State private var password: String = ""

    var body: some View {
        VStack(spacing: 25) {
            Spacer()

            // Logo
            Image("logo")
                .resizable()
                .scaledToFit()
                .frame(width: 120, height: 120)

            // Texto de bienvenida
            Text("Welcome back!\nLogin to your account")
                .font(.headline)
                .multilineTextAlignment(.center)
                .foregroundColor(.black)

            // Campo de usuario
            HStack {
                Image(systemName: "person.fill")
                    .foregroundColor(.gray)
                TextField("Username", text: $username)
                    .autocapitalization(.none)
            }
            .padding()
            .background(Color(UIColor.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)

            // Campo de contraseña
            HStack {
                Image(systemName: "lock.fill")
                    .foregroundColor(.gray)
                SecureField("Password", text: $password)
            }
            .padding()
            .background(Color(UIColor.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)

            // Botón de inicio de sesión (sin lógica)
            NavigationLink(destination: Dashboard_View()) {
                Text("Sign in")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
            }

            // Texto de registro
            Button(action: {
                // Acción futura para registro
            }) {
                Text("Register")
                    .underline()
                    .foregroundColor(.green)
            }

            Spacer()
        }
        .background(Color(.systemGroupedBackground).edgesIgnoringSafeArea(.all))
    }
}

#Preview {
    LoginScreen_View()
}
